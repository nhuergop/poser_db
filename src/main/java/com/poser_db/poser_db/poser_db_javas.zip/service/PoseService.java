package com.poser_db.poser_db.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.poser_db.poser_db.dao.PoseRepository;
import com.poser_db.poser_db.model.Pose;

@Service
public class PoseService {
    private final PoseRepository repository;

    @Autowired
    public PoseService(@Qualifier("mongoDb") PoseRepository repository)
    {
        this.repository = repository;
    }

    public List<Pose> getAllPoses()
    {
        return repository.findAll();
    }

    public void insertPose(Pose pose)
    {
        repository.upsertPose(pose);
    }
}
