package com.poser_db.poser_db.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.client.result.UpdateResult;
import com.poser_db.poser_db.model.Pose;

@Repository("mongoDb")
public class PoseDataAccessService {
    PoseRepository repository;
    
    @Autowired
    private MongoTemplate template;

    public List<Pose> getAllPoses() {
        return repository.findAll();
    }

    public String upsertPose(Pose pose)
    {
        BasicQuery query = new BasicQuery(String.format("{title : %s}", pose.getTitle()));

        Update updateDefinition = new Update().set("title", pose.getTitle());

        UpdateResult updateResult = template.upsert(query, updateDefinition, Pose.class);

        return updateResult.getUpsertedId().toString();
    }

    
}
